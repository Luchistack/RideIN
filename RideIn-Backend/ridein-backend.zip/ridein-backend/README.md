# ridein-backend

Django + Django REST Framework API backend for **RideIN** — a ride-ordering
platform for estate keke (three-wheeler) drivers in Nigeria. This is the
real backend behind the `ridein-frontend` React/Vite app, which currently
mocks everything via `localStorage`.

## Local setup

1. **Create and activate a virtualenv**

   ```bash
   python3 -m venv venv
   source venv/bin/activate
   ```

2. **Install dependencies**

   ```bash
   pip install -r requirements/dev.txt
   ```

3. **Copy the env file and fill in real values**

   ```bash
   cp .env.example .env
   ```

4. **Run Postgres locally via Docker**

   ```bash
   docker run --name ridein-db -e POSTGRES_USER=ridein -e POSTGRES_PASSWORD=password \
     -e POSTGRES_DB=ridein -p 5432:5432 -d postgres:16
   ```

   Make sure `.env`'s `DATABASE_URL` matches, e.g.
   `postgres://ridein:password@localhost:5432/ridein`.

   (If you just want to poke around without Docker, dev settings fall back
   to a local `db.sqlite3` file automatically when `DATABASE_URL` isn't set
   — fine for quick iteration, not what's used in the shipped `.env.example`
   or in production.)

5. **Run migrations**

   ```bash
   python manage.py migrate
   ```

6. **Create a superuser (admin account)**

   Admin accounts are never created through a public signup endpoint — only
   this way:

   ```bash
   python manage.py createsuperuser
   ```

7. **Run the dev server**

   ```bash
   python manage.py runserver
   ```

   The API is now at `http://localhost:8000/api/v1/`, and Django admin at
   `http://localhost:8000/admin/`.

## Running tests

```bash
pytest
```

## Connecting the frontend

Point the frontend's `VITE_API_BASE_URL` at this backend, e.g. in
`ridein-frontend/.env`:

```
VITE_API_BASE_URL=http://localhost:8000/api/v1
```

`dev.py` allows CORS from `http://localhost:5173` (the Vite dev server) by
default.

## Settings

- `config/settings/base.py` — shared settings.
- `config/settings/dev.py` — `DEBUG=True`, permissive CORS for
  `localhost:5173`, sqlite fallback if `DATABASE_URL` is unset.
- `config/settings/prod.py` — `DEBUG=False`, forces HTTPS
  (`SECURE_SSL_REDIRECT`, `SESSION_COOKIE_SECURE`, `CSRF_COOKIE_SECURE`),
  and requires `SECRET_KEY` / `DATABASE_URL` / `ALLOWED_HOSTS` from the
  environment with no defaults — it will fail to start rather than silently
  run insecurely if any are missing.

`manage.py` defaults `DJANGO_SETTINGS_MODULE` to `config.settings.dev` when
the environment variable isn't already set, so `python manage.py runserver`
works out of the box locally. Set `DJANGO_SETTINGS_MODULE=config.settings.prod`
in production.

## API endpoints (all under `/api/v1/`)

### `auth/` (apps/accounts)

| Method | Path | Who | Notes |
|---|---|---|---|
| POST | `auth/signup/passenger/` | public | creates a passenger account |
| POST | `auth/signup/rider/` | public | creates a rider, `verification_status=pending_review` |
| POST | `auth/login/` | public | `{access, refresh, user}` |
| POST | `auth/logout/` | authenticated | blacklists the given refresh token |
| POST | `auth/token/refresh/` | public | exchanges a refresh token for a new access token |
| GET/PATCH | `auth/me/` | authenticated | current user |
| PATCH/PUT | `auth/me/photo/` | authenticated | update profile photo |
| GET | `auth/riders/pending/` | admin | riders awaiting verification |
| POST | `auth/riders/<user_id>/approve/` | admin | set a rider's `verification_status` |

There is deliberately **no** `auth/signup/admin/` route. Admin accounts are
created only via `python manage.py createsuperuser` or a management command.

### `rides/` (apps/rides)

| Method | Path | Who | Notes |
|---|---|---|---|
| POST | `rides/request/` | passenger | creates a ride, status `requested` |
| GET | `rides/mine/` | passenger or rider | rides where you're a participant |
| GET | `rides/available/` | rider | unassigned `requested` rides |
| GET | `rides/<id>/` | participant | ride detail |
| POST | `rides/<id>/accept/` | rider | must be `requested` and unassigned |
| POST | `rides/<id>/cancel/` | passenger or rider (own ride only) | must be in a cancellable status |
| POST | `rides/<id>/complete/` | passenger (own ride only) | optional `rating` (1-5) + `tip_amount` |

### `payments/` (apps/payments)

Bank-transfer-per-ride only — **there is no wallet / stored balance
anywhere** in this backend.

| Method | Path | Who | Notes |
|---|---|---|---|
| POST | `payments/submit/` | passenger | submits a bank reference for one of their own rides |
| GET | `payments/mine/` | passenger or rider | payment history for their rides |
| POST | `payments/<id>/confirm/` | admin | mark `confirmed` or `failed` |

### `locations/` (apps/locations)

REST polling, not WebSockets.

| Method | Path | Who | Notes |
|---|---|---|---|
| POST/PUT | `locations/me/` | any authenticated user | upsert your own current location |
| GET | `locations/<passenger_id>/` | rider | only if the rider has an active (`accepted`/`enroute`) ride with that passenger — enforced in the query, not just the permission class |

### `support/` (apps/support)

| Method | Path | Who | Notes |
|---|---|---|---|
| GET | `support/mine/` | passenger or rider | your own thread (created on first access) |
| POST | `support/mine/messages/` | passenger or rider | post a message into your own thread |
| GET | `support/admin/threads/` | admin | inbox: all threads |
| GET | `support/admin/threads/<id>/` | admin | one thread |
| POST | `support/admin/threads/<id>/reply/` | admin | post a reply |
| POST | `support/admin/threads/<id>/mark-read/` | admin | mark thread's messages read |

## Project layout

```
ridein-backend/
├── manage.py
├── requirements/           base.txt, dev.txt, prod.txt
├── config/                 settings (base/dev/prod), urls, asgi, wsgi
├── apps/
│   ├── accounts/           custom User, RiderProfile, JWT auth, admin views
│   ├── rides/               ride lifecycle
│   ├── payments/            per-ride bank-transfer payments (no wallet)
│   ├── locations/           REST-polled live location sharing
│   ├── support/             customer care chat + admin inbox
│   └── core/                shared pagination / throttling / permissions
└── tests/                   pytest test suite
```
