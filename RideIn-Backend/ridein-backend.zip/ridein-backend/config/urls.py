"""
Root URL configuration.

Every app is mounted under /api/v1/... so the frontend's
VITE_API_BASE_URL=http://localhost:8000/api/v1 hits everything below.
"""
from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path("admin/", admin.site.urls),
    path("api/v1/auth/", include("apps.accounts.urls")),
    path("api/v1/rides/", include("apps.rides.urls")),
    path("api/v1/payments/", include("apps.payments.urls")),
    path("api/v1/locations/", include("apps.locations.urls")),
    path("api/v1/support/", include("apps.support.urls")),
]
