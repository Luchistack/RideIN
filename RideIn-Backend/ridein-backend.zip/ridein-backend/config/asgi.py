"""
ASGI config for the RideIN backend project.

Kept as a plain Django ASGI app for now (REST + polling only, per the plan's
Option A for live location). Swap in Channels' ProtocolTypeRouter here later
if/when WebSocket support (Option B) is added.
"""
import os

from django.core.asgi import get_asgi_application

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings.dev")

application = get_asgi_application()
