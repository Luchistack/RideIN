"""
Local development settings.

- DEBUG on
- Permissive CORS for the Vite dev server (localhost:5173)
- Falls back to sqlite if DATABASE_URL isn't set, so `runserver` works with
  zero setup; point DATABASE_URL at Postgres (see README) for anything real.
"""
from .base import *  # noqa: F401,F403
from .base import BASE_DIR, env

DEBUG = True

SECRET_KEY = env("SECRET_KEY", default="insecure-dev-only-secret-key")

ALLOWED_HOSTS = env.list("ALLOWED_HOSTS", default=["localhost", "127.0.0.1"])

DATABASES = {
    "default": env.db("DATABASE_URL", default=f"sqlite:///{BASE_DIR / 'db.sqlite3'}"),
}

CORS_ALLOWED_ORIGINS = env.list(
    "CORS_ALLOWED_ORIGINS", default=["http://localhost:5173"]
)

EMAIL_BACKEND = "django.core.mail.backends.console.EmailBackend"
