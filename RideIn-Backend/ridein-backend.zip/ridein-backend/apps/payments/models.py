import uuid

from django.db import models

from apps.rides.models import Ride


class Payment(models.Model):
    """A bank-transfer payment for a single ride. The passenger transfers
    money directly to RideIN's bank account and submits the reference here;
    an admin confirms it. There is deliberately NO stored wallet/balance
    anywhere in this app or on User -- every payment ties to exactly one
    ride via a OneToOne.
    """

    class Status(models.TextChoices):
        PENDING = "pending", "Pending"
        CONFIRMED = "confirmed", "Confirmed"
        FAILED = "failed", "Failed"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    ride = models.OneToOneField(Ride, on_delete=models.CASCADE, related_name="payment")
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    bank_reference = models.CharField(max_length=128)
    status = models.CharField(max_length=16, choices=Status.choices, default=Status.PENDING)
    submitted_at = models.DateTimeField(auto_now_add=True)
    confirmed_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-submitted_at"]

    def __str__(self):
        return f"Payment<{self.id}, ride={self.ride_id}, {self.status}>"
