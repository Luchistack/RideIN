from django.utils import timezone
from rest_framework import generics, permissions, status
from rest_framework.exceptions import PermissionDenied, ValidationError
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.accounts.permissions import IsAdmin, IsPassenger

from .models import Payment
from .serializers import ConfirmPaymentSerializer, PaymentSerializer, SubmitPaymentSerializer


class SubmitPaymentView(generics.CreateAPIView):
    """POST /api/v1/payments/submit/ -- passenger submits a bank-transfer
    reference for one of their own rides.
    """

    serializer_class = SubmitPaymentSerializer
    permission_classes = [permissions.IsAuthenticated, IsPassenger]

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        ride = serializer.validated_data["ride"]
        if ride.passenger_id != request.user.id:
            raise PermissionDenied("You can only submit payment for your own ride.")
        if hasattr(ride, "payment"):
            raise ValidationError("A payment already exists for this ride.")

        payment = serializer.save(status=Payment.Status.PENDING)
        return Response(PaymentSerializer(payment).data, status=status.HTTP_201_CREATED)


class MyPaymentHistoryView(generics.ListAPIView):
    """GET /api/v1/payments/mine/ -- payment history for rides belonging to
    the current user (as passenger).
    """

    serializer_class = PaymentSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        if user.is_rider:
            return Payment.objects.filter(ride__rider=user).select_related("ride")
        return Payment.objects.filter(ride__passenger=user).select_related("ride")


class ConfirmPaymentView(APIView):
    """POST /api/v1/payments/<uuid:pk>/confirm/ -- admin only."""

    permission_classes = [IsAdmin]

    def post(self, request, pk):
        payment = generics.get_object_or_404(Payment, pk=pk)
        serializer = ConfirmPaymentSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        payment.status = serializer.validated_data["status"]
        if payment.status == Payment.Status.CONFIRMED:
            payment.confirmed_at = timezone.now()
        payment.save(update_fields=["status", "confirmed_at"])
        return Response(PaymentSerializer(payment).data)
