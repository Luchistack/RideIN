from django.urls import path

from . import views

app_name = "payments"

urlpatterns = [
    path("submit/", views.SubmitPaymentView.as_view(), name="submit"),
    path("mine/", views.MyPaymentHistoryView.as_view(), name="mine"),
    path("<uuid:pk>/confirm/", views.ConfirmPaymentView.as_view(), name="confirm"),
]
