from django.contrib import admin

from .models import Payment


@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ["id", "ride", "amount", "bank_reference", "status", "submitted_at"]
    list_filter = ["status"]
    search_fields = ["bank_reference", "ride__id"]
    readonly_fields = ["id", "submitted_at"]
