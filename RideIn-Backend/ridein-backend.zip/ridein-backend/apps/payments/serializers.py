from rest_framework import serializers

from .models import Payment


class PaymentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Payment
        fields = [
            "id",
            "ride",
            "amount",
            "bank_reference",
            "status",
            "submitted_at",
            "confirmed_at",
        ]
        read_only_fields = ["id", "status", "submitted_at", "confirmed_at"]


class SubmitPaymentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Payment
        fields = ["ride", "amount", "bank_reference"]


class ConfirmPaymentSerializer(serializers.Serializer):
    status = serializers.ChoiceField(choices=[Payment.Status.CONFIRMED, Payment.Status.FAILED])
