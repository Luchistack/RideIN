from django.utils import timezone
from rest_framework import generics, permissions, status
from rest_framework.exceptions import PermissionDenied, ValidationError
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.accounts.permissions import IsPassenger, IsRider

from .models import Ride
from .permissions import IsRideParticipant
from .serializers import RideCompleteSerializer, RideRequestSerializer, RideSerializer


class RideRequestView(generics.CreateAPIView):
    """POST /api/v1/rides/request/ -- passenger only."""

    serializer_class = RideRequestSerializer
    permission_classes = [permissions.IsAuthenticated, IsPassenger]

    def perform_create(self, serializer):
        serializer.save(passenger=self.request.user, status=Ride.Status.REQUESTED)

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        ride = serializer.instance
        return Response(RideSerializer(ride).data, status=status.HTTP_201_CREATED)


class MyRidesListView(generics.ListAPIView):
    """GET /api/v1/rides/mine/ -- rides for the current user, either role."""

    serializer_class = RideSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        if user.is_rider:
            return Ride.objects.filter(rider=user).select_related("passenger", "rider")
        return Ride.objects.filter(passenger=user).select_related("passenger", "rider")


class AvailableRidesListView(generics.ListAPIView):
    """GET /api/v1/rides/available/ -- rider only: pending (requested,
    unassigned) ride requests a rider can accept.
    """

    serializer_class = RideSerializer
    permission_classes = [permissions.IsAuthenticated, IsRider]

    def get_queryset(self):
        return Ride.objects.filter(
            status=Ride.Status.REQUESTED, rider__isnull=True
        ).select_related("passenger", "rider")


class RideDetailView(generics.RetrieveAPIView):
    """GET /api/v1/rides/<uuid:pk>/"""

    serializer_class = RideSerializer
    permission_classes = [permissions.IsAuthenticated, IsRideParticipant]
    queryset = Ride.objects.select_related("passenger", "rider")


class AcceptRideView(APIView):
    """POST /api/v1/rides/<uuid:pk>/accept/ -- rider only."""

    permission_classes = [permissions.IsAuthenticated, IsRider]

    def post(self, request, pk):
        try:
            ride = Ride.objects.select_related("passenger", "rider").get(pk=pk)
        except Ride.DoesNotExist:
            return Response({"detail": "Ride not found."}, status=status.HTTP_404_NOT_FOUND)

        if ride.status != Ride.Status.REQUESTED or ride.rider_id is not None:
            raise ValidationError("This ride is no longer available to accept.")

        ride.rider = request.user
        ride.status = Ride.Status.ACCEPTED
        ride.accepted_at = timezone.now()
        ride.save(update_fields=["rider", "status", "accepted_at"])
        return Response(RideSerializer(ride).data)


class CancelRideView(APIView):
    """POST /api/v1/rides/<uuid:pk>/cancel/ -- passenger or rider, must own
    the ride, and it must be in a cancellable status.
    """

    permission_classes = [permissions.IsAuthenticated, IsRideParticipant]

    def post(self, request, pk):
        ride = generics.get_object_or_404(Ride.objects.select_related("passenger", "rider"), pk=pk)
        self.check_object_permissions(request, ride)

        user = request.user
        if ride.passenger_id != user.id and ride.rider_id != user.id:
            raise PermissionDenied("You do not own this ride.")

        if ride.status not in Ride.CANCELLABLE_STATUSES:
            raise ValidationError("This ride can no longer be cancelled.")

        if user.is_rider and ride.rider_id == user.id:
            ride.status = Ride.Status.CANCELLED_BY_RIDER
        elif user.is_passenger and ride.passenger_id == user.id:
            ride.status = Ride.Status.CANCELLED_BY_PASSENGER
        else:
            raise PermissionDenied("You do not own this ride.")

        ride.cancelled_at = timezone.now()
        ride.cancelled_by = user
        ride.save(update_fields=["status", "cancelled_at", "cancelled_by"])
        return Response(RideSerializer(ride).data)


class CompleteRideView(APIView):
    """POST /api/v1/rides/<uuid:pk>/complete/ -- passenger only. Optionally
    rates the ride (1-5) and/or adds a tip in the same call.
    """

    permission_classes = [permissions.IsAuthenticated, IsPassenger, IsRideParticipant]

    def post(self, request, pk):
        ride = generics.get_object_or_404(Ride.objects.select_related("passenger", "rider"), pk=pk)
        self.check_object_permissions(request, ride)

        if ride.passenger_id != request.user.id:
            raise PermissionDenied("You do not own this ride.")

        if ride.status not in (Ride.Status.ACCEPTED, Ride.Status.ENROUTE):
            raise ValidationError("This ride cannot be completed from its current status.")

        serializer = RideCompleteSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        ride.status = Ride.Status.COMPLETED
        ride.completed_at = timezone.now()
        if "rating" in serializer.validated_data:
            ride.rating = serializer.validated_data["rating"]
        if "tip_amount" in serializer.validated_data:
            ride.tip_amount = serializer.validated_data["tip_amount"]
        ride.save(update_fields=["status", "completed_at", "rating", "tip_amount"])
        return Response(RideSerializer(ride).data)
