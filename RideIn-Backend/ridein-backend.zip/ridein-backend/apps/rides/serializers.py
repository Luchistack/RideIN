from decimal import Decimal

from rest_framework import serializers

from apps.accounts.serializers import UserSerializer

from .models import Ride


class RideSerializer(serializers.ModelSerializer):
    passenger = UserSerializer(read_only=True)
    rider = UserSerializer(read_only=True)

    class Meta:
        model = Ride
        fields = [
            "id",
            "passenger",
            "rider",
            "status",
            "pickup_lat",
            "pickup_lng",
            "dropoff_lat",
            "dropoff_lng",
            "fare",
            "tip_amount",
            "rating",
            "requested_at",
            "accepted_at",
            "completed_at",
            "cancelled_at",
            "cancelled_by",
        ]
        read_only_fields = [
            "id",
            "passenger",
            "rider",
            "status",
            "fare",
            "tip_amount",
            "rating",
            "requested_at",
            "accepted_at",
            "completed_at",
            "cancelled_at",
            "cancelled_by",
        ]


class RideRequestSerializer(serializers.ModelSerializer):
    class Meta:
        model = Ride
        fields = ["pickup_lat", "pickup_lng", "dropoff_lat", "dropoff_lng", "fare"]


class RideCompleteSerializer(serializers.Serializer):
    rating = serializers.IntegerField(min_value=1, max_value=5, required=False)
    tip_amount = serializers.DecimalField(
        max_digits=10, decimal_places=2, required=False, min_value=Decimal("0")
    )
