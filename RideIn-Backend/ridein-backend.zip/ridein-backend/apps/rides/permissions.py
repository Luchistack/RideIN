from rest_framework.permissions import BasePermission


class IsRideParticipant(BasePermission):
    """Object-level: only the ride's own passenger or own rider may act on it."""

    def has_object_permission(self, request, view, obj):
        user = request.user
        return obj.passenger_id == user.id or obj.rider_id == user.id
