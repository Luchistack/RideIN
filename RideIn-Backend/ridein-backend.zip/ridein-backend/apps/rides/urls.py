from django.urls import path

from . import views

app_name = "rides"

urlpatterns = [
    path("request/", views.RideRequestView.as_view(), name="request"),
    path("mine/", views.MyRidesListView.as_view(), name="mine"),
    path("available/", views.AvailableRidesListView.as_view(), name="available"),
    path("<uuid:pk>/", views.RideDetailView.as_view(), name="detail"),
    path("<uuid:pk>/accept/", views.AcceptRideView.as_view(), name="accept"),
    path("<uuid:pk>/cancel/", views.CancelRideView.as_view(), name="cancel"),
    path("<uuid:pk>/complete/", views.CompleteRideView.as_view(), name="complete"),
]
