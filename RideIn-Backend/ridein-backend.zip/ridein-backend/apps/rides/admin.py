from django.contrib import admin

from .models import Ride


@admin.register(Ride)
class RideAdmin(admin.ModelAdmin):
    list_display = ["id", "passenger", "rider", "status", "fare", "rating", "requested_at"]
    list_filter = ["status"]
    search_fields = ["passenger__email", "rider__email", "id"]
    readonly_fields = ["id", "requested_at"]
