import uuid

from django.conf import settings
from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models


class Ride(models.Model):
    class Status(models.TextChoices):
        REQUESTED = "requested", "Requested"
        ACCEPTED = "accepted", "Accepted"
        ENROUTE = "enroute", "Enroute"
        COMPLETED = "completed", "Completed"
        CANCELLED_BY_PASSENGER = "cancelled_by_passenger", "Cancelled by passenger"
        CANCELLED_BY_RIDER = "cancelled_by_rider", "Cancelled by rider"

    ACTIVE_STATUSES = (Status.ACCEPTED, Status.ENROUTE)
    CANCELLABLE_STATUSES = (Status.REQUESTED, Status.ACCEPTED, Status.ENROUTE)

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    passenger = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="rides_as_passenger"
    )
    rider = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        related_name="rides_as_rider",
        null=True,
        blank=True,
    )
    status = models.CharField(
        max_length=32, choices=Status.choices, default=Status.REQUESTED
    )

    pickup_lat = models.DecimalField(max_digits=9, decimal_places=6)
    pickup_lng = models.DecimalField(max_digits=9, decimal_places=6)
    dropoff_lat = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    dropoff_lng = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)

    fare = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    tip_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    rating = models.PositiveSmallIntegerField(
        null=True, blank=True, validators=[MinValueValidator(1), MaxValueValidator(5)]
    )

    requested_at = models.DateTimeField(auto_now_add=True)
    accepted_at = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    cancelled_at = models.DateTimeField(null=True, blank=True)
    cancelled_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        related_name="rides_cancelled",
        null=True,
        blank=True,
    )

    class Meta:
        ordering = ["-requested_at"]

    def __str__(self):
        return f"Ride<{self.id}, {self.status}>"

    @property
    def is_active(self):
        return self.status in self.ACTIVE_STATUSES
