from rest_framework.throttling import ScopedRateThrottle


class AuthRateThrottle(ScopedRateThrottle):
    """Applied to signup/login views. Rate is controlled centrally via
    REST_FRAMEWORK['DEFAULT_THROTTLE_RATES']['auth'] (see settings/base.py).
    """

    scope = "auth"
