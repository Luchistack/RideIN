"""Shared permission classes that aren't tied to a specific role.

Role-specific permissions (IsPassenger, IsRider, IsAdmin, ...) live in
apps/accounts/permissions.py and are imported by the other apps.
"""
from rest_framework.permissions import BasePermission, SAFE_METHODS


class IsOwnerOrReadOnly(BasePermission):
    """Object-level permission: only the owner (obj.user or obj.owner) may
    write; anyone with view access may read.
    """

    def has_object_permission(self, request, view, obj):
        if request.method in SAFE_METHODS:
            return True
        owner = getattr(obj, "user", None) or getattr(obj, "owner", None)
        return owner == request.user
