from rest_framework import generics, permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.accounts.permissions import IsAdmin

from .models import SupportMessage, SupportThread
from .serializers import PostMessageSerializer, SupportMessageSerializer, SupportThreadSerializer


class MyThreadView(APIView):
    """GET /api/v1/support/mine/ -- passenger or rider: fetch (creating if
    needed) their own support thread with all messages.
    """

    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        thread, _ = SupportThread.objects.get_or_create(user=request.user)
        return Response(SupportThreadSerializer(thread).data)


class PostMyMessageView(generics.CreateAPIView):
    """POST /api/v1/support/mine/messages/ -- passenger or rider posts a
    message into their own thread.
    """

    serializer_class = PostMessageSerializer
    permission_classes = [permissions.IsAuthenticated]

    def create(self, request, *args, **kwargs):
        thread, _ = SupportThread.objects.get_or_create(user=request.user)
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        message = serializer.save(thread=thread, sender=request.user, read_by_admin=False)
        return Response(SupportMessageSerializer(message).data, status=status.HTTP_201_CREATED)


class AdminThreadListView(generics.ListAPIView):
    """GET /api/v1/support/admin/threads/ -- admin inbox: all threads."""

    serializer_class = SupportThreadSerializer
    permission_classes = [IsAdmin]
    queryset = SupportThread.objects.select_related("user").prefetch_related("messages")


class AdminThreadDetailView(generics.RetrieveAPIView):
    """GET /api/v1/support/admin/threads/<uuid:pk>/"""

    serializer_class = SupportThreadSerializer
    permission_classes = [IsAdmin]
    queryset = SupportThread.objects.select_related("user").prefetch_related("messages")


class AdminReplyView(generics.CreateAPIView):
    """POST /api/v1/support/admin/threads/<uuid:pk>/reply/ -- admin reply."""

    serializer_class = PostMessageSerializer
    permission_classes = [IsAdmin]

    def create(self, request, *args, **kwargs):
        thread = generics.get_object_or_404(SupportThread, pk=kwargs["pk"])
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        message = serializer.save(thread=thread, sender=request.user, read_by_admin=True)
        return Response(SupportMessageSerializer(message).data, status=status.HTTP_201_CREATED)


class AdminMarkReadView(APIView):
    """POST /api/v1/support/admin/threads/<uuid:pk>/mark-read/"""

    permission_classes = [IsAdmin]

    def post(self, request, pk):
        thread = generics.get_object_or_404(SupportThread, pk=pk)
        SupportMessage.objects.filter(thread=thread, read_by_admin=False).update(read_by_admin=True)
        return Response(SupportThreadSerializer(thread).data)
