from django.contrib import admin

from .models import SupportMessage, SupportThread


class SupportMessageInline(admin.TabularInline):
    model = SupportMessage
    extra = 0
    readonly_fields = ["id", "sender", "body", "created_at", "read_by_admin"]


@admin.register(SupportThread)
class SupportThreadAdmin(admin.ModelAdmin):
    list_display = ["id", "user", "created_at", "updated_at"]
    search_fields = ["user__email"]
    inlines = [SupportMessageInline]


@admin.register(SupportMessage)
class SupportMessageAdmin(admin.ModelAdmin):
    list_display = ["id", "thread", "sender", "created_at", "read_by_admin"]
    list_filter = ["read_by_admin"]
