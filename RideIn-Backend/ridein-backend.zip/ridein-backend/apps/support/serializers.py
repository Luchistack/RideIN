from rest_framework import serializers

from apps.accounts.serializers import UserSerializer

from .models import SupportMessage, SupportThread


class SupportMessageSerializer(serializers.ModelSerializer):
    sender = UserSerializer(read_only=True)

    class Meta:
        model = SupportMessage
        fields = ["id", "thread", "sender", "body", "created_at", "read_by_admin"]
        read_only_fields = ["id", "thread", "sender", "created_at", "read_by_admin"]


class PostMessageSerializer(serializers.ModelSerializer):
    class Meta:
        model = SupportMessage
        fields = ["body"]


class SupportThreadSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)
    messages = SupportMessageSerializer(many=True, read_only=True)

    class Meta:
        model = SupportThread
        fields = ["id", "user", "messages", "created_at", "updated_at"]
        read_only_fields = fields
