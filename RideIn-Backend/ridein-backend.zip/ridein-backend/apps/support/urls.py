from django.urls import path

from . import views

app_name = "support"

urlpatterns = [
    path("mine/", views.MyThreadView.as_view(), name="mine"),
    path("mine/messages/", views.PostMyMessageView.as_view(), name="mine-post"),
    path("admin/threads/", views.AdminThreadListView.as_view(), name="admin-threads"),
    path("admin/threads/<uuid:pk>/", views.AdminThreadDetailView.as_view(), name="admin-thread-detail"),
    path("admin/threads/<uuid:pk>/reply/", views.AdminReplyView.as_view(), name="admin-reply"),
    path("admin/threads/<uuid:pk>/mark-read/", views.AdminMarkReadView.as_view(), name="admin-mark-read"),
]
