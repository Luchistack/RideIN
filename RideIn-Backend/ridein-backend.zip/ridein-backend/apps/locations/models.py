from django.conf import settings
from django.db import models


class LiveLocation(models.Model):
    """One row per user, upserted on every location update. REST polling
    (not WebSockets) per the plan's "Option A" -- simplest thing that works.
    """

    user = models.OneToOneField(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="live_location"
    )
    lat = models.DecimalField(max_digits=9, decimal_places=6)
    lng = models.DecimalField(max_digits=9, decimal_places=6)
    accuracy = models.FloatField(null=True, blank=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"LiveLocation<{self.user_id}>"
