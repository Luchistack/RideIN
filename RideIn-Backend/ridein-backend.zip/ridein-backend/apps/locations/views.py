from rest_framework import permissions, status
from rest_framework.generics import get_object_or_404
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.accounts.permissions import IsRider
from apps.rides.models import Ride

from .models import LiveLocation
from .serializers import LiveLocationSerializer


class MyLocationView(APIView):
    """POST/PUT /api/v1/locations/me/ -- any authenticated user upserts
    their own current location.
    """

    permission_classes = [permissions.IsAuthenticated]

    def _upsert(self, request):
        serializer = LiveLocationSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        location, _ = LiveLocation.objects.update_or_create(
            user=request.user, defaults=serializer.validated_data
        )
        return Response(LiveLocationSerializer(location).data)

    def post(self, request):
        return self._upsert(request)

    def put(self, request):
        return self._upsert(request)


class PassengerLocationView(APIView):
    """GET /api/v1/locations/<uuid:passenger_id>/ -- rider only, and only if
    the requesting rider currently has an active (accepted/enroute) ride
    with that passenger. This is enforced in the queryset lookup itself
    (not just via permission_classes) so a rider can never fetch a
    passenger's location outside of that shared active ride.
    """

    permission_classes = [permissions.IsAuthenticated, IsRider]

    def get(self, request, passenger_id):
        has_active_shared_ride = Ride.objects.filter(
            rider=request.user,
            passenger_id=passenger_id,
            status__in=Ride.ACTIVE_STATUSES,
        ).exists()
        if not has_active_shared_ride:
            return Response(
                {"detail": "No active shared ride with this passenger."},
                status=status.HTTP_403_FORBIDDEN,
            )

        location = get_object_or_404(LiveLocation, user_id=passenger_id)
        return Response(LiveLocationSerializer(location).data)
