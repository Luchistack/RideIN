from rest_framework.permissions import BasePermission

from apps.accounts.permissions import IsRider  # re-exported for convenience

__all__ = ["IsRider"]


class IsSelfOrRiderOfActiveRide(BasePermission):
    """Placeholder object-level check; the real scoping for reading a
    passenger's location happens in the queryset (PassengerLocationView),
    since it must never leak existence of a location outside an active
    shared ride -- enforcing it only here would still allow a 404 vs 403
    timing/oracle difference. Kept as a defense-in-depth no-op base class.
    """

    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated)
