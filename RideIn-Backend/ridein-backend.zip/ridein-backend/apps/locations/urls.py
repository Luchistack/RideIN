from django.urls import path

from . import views

app_name = "locations"

urlpatterns = [
    path("me/", views.MyLocationView.as_view(), name="me"),
    path("<uuid:passenger_id>/", views.PassengerLocationView.as_view(), name="passenger-location"),
]
