from rest_framework import serializers

from .models import LiveLocation


class LiveLocationSerializer(serializers.ModelSerializer):
    class Meta:
        model = LiveLocation
        fields = ["user", "lat", "lng", "accuracy", "updated_at"]
        read_only_fields = ["user", "updated_at"]
