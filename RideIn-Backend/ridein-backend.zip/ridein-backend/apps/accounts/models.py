import uuid

from django.contrib.auth.base_user import AbstractBaseUser
from django.contrib.auth.models import PermissionsMixin
from django.db import models
from django.utils import timezone

from .managers import UserManager


def rider_photo_path(instance, filename):
    return f"rider_photos/{instance.pk}/{filename}"


def rider_id_document_path(instance, filename):
    return f"rider_id_documents/{instance.pk}/{filename}"


class User(AbstractBaseUser, PermissionsMixin):
    """Custom user model, keyed by email instead of username.

    A real DB-level UNIQUE constraint on `email` is the deliberate fix for a
    known frontend bug where duplicate emails across roles caused login to
    resolve to the wrong account -- this makes that class of bug structurally
    impossible instead of something that has to be remembered/checked for.
    """

    class Role(models.TextChoices):
        PASSENGER = "passenger", "Passenger"
        RIDER = "rider", "Rider"
        ADMIN = "admin", "Admin"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    email = models.EmailField(unique=True)
    name = models.CharField(max_length=150, blank=True)
    phone = models.CharField(max_length=32, blank=True)
    role = models.CharField(max_length=16, choices=Role.choices, default=Role.PASSENGER)
    photo = models.ImageField(upload_to=rider_photo_path, blank=True, null=True)

    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)
    date_joined = models.DateTimeField(default=timezone.now)

    objects = UserManager()

    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = []

    class Meta:
        ordering = ["-date_joined"]

    def __str__(self):
        return f"{self.email} ({self.role})"

    @property
    def is_passenger(self):
        return self.role == self.Role.PASSENGER

    @property
    def is_rider(self):
        return self.role == self.Role.RIDER

    @property
    def is_admin_role(self):
        return self.role == self.Role.ADMIN


class RiderProfile(models.Model):
    """Rider-only extension fields. One-to-one with User."""

    class VerificationStatus(models.TextChoices):
        PENDING_REVIEW = "pending_review", "Pending review"
        APPROVED = "approved", "Approved"
        REJECTED = "rejected", "Rejected"

    user = models.OneToOneField(
        User, on_delete=models.CASCADE, related_name="rider_profile"
    )
    estate = models.CharField(max_length=150, blank=True)
    vehicle_plate = models.CharField(max_length=32, blank=True)
    verification_status = models.CharField(
        max_length=20,
        choices=VerificationStatus.choices,
        default=VerificationStatus.PENDING_REVIEW,
    )
    id_document = models.ImageField(
        upload_to=rider_id_document_path, blank=True, null=True
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"RiderProfile<{self.user.email}, {self.verification_status}>"
