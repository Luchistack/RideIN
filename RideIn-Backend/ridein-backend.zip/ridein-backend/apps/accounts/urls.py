from django.urls import path
from rest_framework_simplejwt.views import TokenRefreshView

from . import views

app_name = "accounts"

urlpatterns = [
    path("signup/passenger/", views.PassengerSignupView.as_view(), name="signup-passenger"),
    path("signup/rider/", views.RiderSignupView.as_view(), name="signup-rider"),
    path("login/", views.LoginView.as_view(), name="login"),
    path("logout/", views.LogoutView.as_view(), name="logout"),
    path("token/refresh/", TokenRefreshView.as_view(), name="token-refresh"),
    path("me/", views.MeView.as_view(), name="me"),
    path("me/photo/", views.UpdatePhotoView.as_view(), name="update-photo"),
    path("riders/pending/", views.PendingRidersListView.as_view(), name="riders-pending"),
    path("riders/<uuid:user_id>/approve/", views.ApproveRiderView.as_view(), name="approve-rider"),
]
