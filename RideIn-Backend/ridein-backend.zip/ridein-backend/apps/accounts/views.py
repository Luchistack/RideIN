from rest_framework import generics, permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.exceptions import TokenError
from rest_framework_simplejwt.tokens import RefreshToken

from apps.core.throttling import AuthRateThrottle

from .models import RiderProfile, User
from .permissions import IsAdmin
from .serializers import (
    ApproveRiderSerializer,
    LoginSerializer,
    PassengerSignupSerializer,
    RiderSignupSerializer,
    UpdatePhotoSerializer,
    UserSerializer,
)


class PassengerSignupView(generics.CreateAPIView):
    """POST /api/v1/auth/signup/passenger/

    Public. Creates a passenger account and returns tokens + the user.
    There is deliberately no equivalent admin signup route anywhere.
    """

    serializer_class = PassengerSignupSerializer
    permission_classes = [permissions.AllowAny]
    throttle_classes = [AuthRateThrottle]
    throttle_scope = "auth"


class RiderSignupView(generics.CreateAPIView):
    """POST /api/v1/auth/signup/rider/

    Public. Creates a rider account with verification_status=pending_review.
    """

    serializer_class = RiderSignupSerializer
    permission_classes = [permissions.AllowAny]
    throttle_classes = [AuthRateThrottle]
    throttle_scope = "auth"


class LoginView(APIView):
    """POST /api/v1/auth/login/ -> {access, refresh, user}"""

    permission_classes = [permissions.AllowAny]
    throttle_classes = [AuthRateThrottle]
    throttle_scope = "auth"

    def post(self, request):
        serializer = LoginSerializer(data=request.data, context={"request": request})
        serializer.is_valid(raise_exception=True)
        return Response(serializer.data, status=status.HTTP_200_OK)


class LogoutView(APIView):
    """POST /api/v1/auth/logout/ {refresh} -> blacklists the refresh token."""

    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        refresh = request.data.get("refresh")
        if not refresh:
            return Response(
                {"detail": "refresh token is required."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        try:
            token = RefreshToken(refresh)
            token.blacklist()
        except TokenError:
            return Response(
                {"detail": "Invalid or already-blacklisted token."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        return Response(status=status.HTTP_205_RESET_CONTENT)


class MeView(generics.RetrieveUpdateAPIView):
    """GET/PATCH /api/v1/auth/me/ -- current user, role-aware."""

    serializer_class = UserSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_object(self):
        return self.request.user


class UpdatePhotoView(generics.UpdateAPIView):
    """PATCH/PUT /api/v1/auth/me/photo/"""

    serializer_class = UpdatePhotoSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_object(self):
        return self.request.user


class PendingRidersListView(generics.ListAPIView):
    """GET /api/v1/auth/riders/pending/ -- admin only."""

    serializer_class = UserSerializer
    permission_classes = [IsAdmin]

    def get_queryset(self):
        return User.objects.filter(
            role=User.Role.RIDER,
            rider_profile__verification_status=RiderProfile.VerificationStatus.PENDING_REVIEW,
        ).select_related("rider_profile")


class ApproveRiderView(APIView):
    """POST /api/v1/auth/riders/<uuid:user_id>/approve/ -- admin only.

    Body: {"verification_status": "approved"|"rejected"|"pending_review"}
    """

    permission_classes = [IsAdmin]

    def post(self, request, user_id):
        try:
            rider_profile = RiderProfile.objects.select_related("user").get(
                user_id=user_id, user__role=User.Role.RIDER
            )
        except RiderProfile.DoesNotExist:
            return Response(
                {"detail": "Rider not found."}, status=status.HTTP_404_NOT_FOUND
            )

        serializer = ApproveRiderSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        rider_profile.verification_status = serializer.validated_data["verification_status"]
        rider_profile.save(update_fields=["verification_status", "updated_at"])
        return Response(UserSerializer(rider_profile.user).data)
