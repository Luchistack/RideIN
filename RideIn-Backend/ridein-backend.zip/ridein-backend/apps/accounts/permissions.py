from rest_framework.permissions import BasePermission


class IsPassenger(BasePermission):
    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated and request.user.is_passenger)


class IsRider(BasePermission):
    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated and request.user.is_rider)


class IsAdmin(BasePermission):
    def has_permission(self, request, view):
        return bool(
            request.user
            and request.user.is_authenticated
            and (request.user.is_admin_role or request.user.is_staff)
        )


class IsOwnerOrAdmin(BasePermission):
    """Object-level: the request.user must be the object's owner (obj.user,
    or the object itself if it *is* a user) or an admin.
    """

    def has_object_permission(self, request, view, obj):
        user = request.user
        if not (user and user.is_authenticated):
            return False
        if user.is_admin_role or user.is_staff:
            return True
        owner = obj if obj.__class__ is user.__class__ else getattr(obj, "user", None)
        return owner == user
