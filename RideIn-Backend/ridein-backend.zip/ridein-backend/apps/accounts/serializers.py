from django.contrib.auth import authenticate
from rest_framework import serializers
from rest_framework_simplejwt.tokens import RefreshToken

from .models import RiderProfile, User


class RiderProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = RiderProfile
        fields = [
            "estate",
            "vehicle_plate",
            "verification_status",
            "id_document",
            "created_at",
            "updated_at",
        ]
        read_only_fields = ["verification_status", "created_at", "updated_at"]


class UserSerializer(serializers.ModelSerializer):
    """Read-facing representation of a user, used in /me/, login responses,
    admin listings, etc.
    """

    rider_profile = RiderProfileSerializer(read_only=True)

    class Meta:
        model = User
        fields = [
            "id",
            "email",
            "name",
            "phone",
            "role",
            "photo",
            "is_active",
            "date_joined",
            "rider_profile",
        ]
        read_only_fields = ["id", "role", "is_active", "date_joined"]


def _token_pair_for(user):
    refresh = RefreshToken.for_user(user)
    return {"access": str(refresh.access_token), "refresh": str(refresh)}


class PassengerSignupSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, min_length=8)

    class Meta:
        model = User
        fields = ["email", "password", "name", "phone"]

    def create(self, validated_data):
        password = validated_data.pop("password")
        user = User.objects.create_user(
            password=password, role=User.Role.PASSENGER, **validated_data
        )
        return user

    def to_representation(self, instance):
        return {"user": UserSerializer(instance).data, **_token_pair_for(instance)}


class RiderSignupSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, min_length=8)
    estate = serializers.CharField(write_only=True, required=False, allow_blank=True)
    vehicle_plate = serializers.CharField(write_only=True, required=False, allow_blank=True)

    class Meta:
        model = User
        fields = ["email", "password", "name", "phone", "estate", "vehicle_plate"]

    def create(self, validated_data):
        password = validated_data.pop("password")
        estate = validated_data.pop("estate", "")
        vehicle_plate = validated_data.pop("vehicle_plate", "")
        user = User.objects.create_user(
            password=password, role=User.Role.RIDER, **validated_data
        )
        RiderProfile.objects.create(
            user=user,
            estate=estate,
            vehicle_plate=vehicle_plate,
            verification_status=RiderProfile.VerificationStatus.PENDING_REVIEW,
        )
        return user

    def to_representation(self, instance):
        return {"user": UserSerializer(instance).data, **_token_pair_for(instance)}


class LoginSerializer(serializers.Serializer):
    email = serializers.EmailField()
    password = serializers.CharField(write_only=True)

    def validate(self, attrs):
        user = authenticate(
            request=self.context.get("request"),
            username=attrs["email"],
            password=attrs["password"],
        )
        if user is None:
            raise serializers.ValidationError("Invalid email or password.")
        if not user.is_active:
            raise serializers.ValidationError("This account is disabled.")
        attrs["user"] = user
        return attrs

    def to_representation(self, instance):
        user = instance["user"]
        return {"user": UserSerializer(user).data, **_token_pair_for(user)}


class UpdatePhotoSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ["photo"]


class ApproveRiderSerializer(serializers.Serializer):
    verification_status = serializers.ChoiceField(
        choices=RiderProfile.VerificationStatus.choices
    )
