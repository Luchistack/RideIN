import pytest

from apps.rides.models import Ride

pytestmark = pytest.mark.django_db


def test_rider_cannot_see_passenger_location_without_active_ride(
    rider_client, passenger_client, passenger_user
):
    passenger_client.post(
        "/api/v1/locations/me/", {"lat": "6.500000", "lng": "3.500000"}
    )
    response = rider_client.get(f"/api/v1/locations/{passenger_user.id}/")
    assert response.status_code == 403


def test_rider_can_see_passenger_location_on_active_ride(
    rider_client, passenger_client, rider_user, passenger_user
):
    ride = Ride.objects.create(
        passenger=passenger_user,
        rider=rider_user,
        status=Ride.Status.ACCEPTED,
        pickup_lat="6.500000",
        pickup_lng="3.500000",
    )
    passenger_client.post(
        "/api/v1/locations/me/", {"lat": "6.512345", "lng": "3.512345"}
    )
    response = rider_client.get(f"/api/v1/locations/{passenger_user.id}/")
    assert response.status_code == 200
    assert response.data["lat"] == "6.512345"

    ride.status = Ride.Status.COMPLETED
    ride.save(update_fields=["status"])

    response = rider_client.get(f"/api/v1/locations/{passenger_user.id}/")
    assert response.status_code == 403


def test_user_can_upsert_own_location(passenger_client):
    response = passenger_client.post(
        "/api/v1/locations/me/", {"lat": "6.500000", "lng": "3.500000"}
    )
    assert response.status_code == 200

    response = passenger_client.put(
        "/api/v1/locations/me/", {"lat": "6.600000", "lng": "3.600000"}
    )
    assert response.status_code == 200
    assert response.data["lat"] == "6.600000"


def test_passenger_cannot_use_passenger_location_endpoint(passenger_client, rider_user):
    response = passenger_client.get(f"/api/v1/locations/{rider_user.id}/")
    assert response.status_code == 403
