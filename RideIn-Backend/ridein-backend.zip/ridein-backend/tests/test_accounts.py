import pytest

from apps.accounts.models import User

pytestmark = pytest.mark.django_db


def test_signup_passenger(api_client):
    response = api_client.post(
        "/api/v1/auth/signup/passenger/",
        {"email": "newpassenger@example.com", "password": "testpass123", "name": "New Passenger"},
    )
    assert response.status_code == 201
    assert response.data["user"]["role"] == "passenger"
    assert "access" in response.data
    assert "refresh" in response.data
    assert User.objects.filter(email="newpassenger@example.com").exists()


def test_signup_rider(api_client):
    response = api_client.post(
        "/api/v1/auth/signup/rider/",
        {
            "email": "newrider@example.com",
            "password": "testpass123",
            "name": "New Rider",
            "estate": "Palm Estate",
            "vehicle_plate": "ABC-999ZZ",
        },
    )
    assert response.status_code == 201
    assert response.data["user"]["role"] == "rider"
    assert response.data["user"]["rider_profile"]["verification_status"] == "pending_review"


def test_duplicate_email_rejected_across_roles(api_client):
    api_client.post(
        "/api/v1/auth/signup/passenger/",
        {"email": "dupe@example.com", "password": "testpass123", "name": "First"},
    )
    response = api_client.post(
        "/api/v1/auth/signup/rider/",
        {"email": "dupe@example.com", "password": "testpass123", "name": "Second"},
    )
    assert response.status_code == 400


def test_login(api_client, passenger_user):
    response = api_client.post(
        "/api/v1/auth/login/",
        {"email": passenger_user.email, "password": "testpass123"},
    )
    assert response.status_code == 200
    assert response.data["user"]["email"] == passenger_user.email
    assert "access" in response.data


def test_login_wrong_password(api_client, passenger_user):
    response = api_client.post(
        "/api/v1/auth/login/",
        {"email": passenger_user.email, "password": "wrongpassword"},
    )
    assert response.status_code == 400


def test_me_endpoint(passenger_client, passenger_user):
    response = passenger_client.get("/api/v1/auth/me/")
    assert response.status_code == 200
    assert response.data["email"] == passenger_user.email
    assert response.data["role"] == "passenger"


def test_me_requires_auth(api_client):
    response = api_client.get("/api/v1/auth/me/")
    assert response.status_code == 401


def test_no_admin_signup_route(api_client):
    response = api_client.post(
        "/api/v1/auth/signup/admin/",
        {"email": "sneaky@example.com", "password": "testpass123"},
    )
    assert response.status_code == 404
