import pytest
from django.core.cache import cache
from rest_framework.test import APIClient
from rest_framework_simplejwt.tokens import RefreshToken

from apps.accounts.models import RiderProfile, User


@pytest.fixture(autouse=True)
def _clear_throttle_cache():
    """DRF's ScopedRateThrottle counters live in the default cache, which
    persists across tests (it isn't reset by Django's per-test DB
    transaction rollback). Clear it before every test so the 'auth' scope
    throttle (5/min) on signup/login doesn't bleed between test cases.
    """
    cache.clear()
    yield
    cache.clear()


@pytest.fixture
def passenger_user(db):
    return User.objects.create_user(
        email="passenger@example.com",
        password="testpass123",
        name="Pat Passenger",
        role=User.Role.PASSENGER,
    )


@pytest.fixture
def rider_user(db):
    user = User.objects.create_user(
        email="rider@example.com",
        password="testpass123",
        name="Rita Rider",
        role=User.Role.RIDER,
    )
    RiderProfile.objects.create(
        user=user,
        estate="Sunrise Estate",
        vehicle_plate="KJA-123XY",
        verification_status=RiderProfile.VerificationStatus.APPROVED,
    )
    return user


@pytest.fixture
def admin_user(db):
    return User.objects.create_superuser(
        email="admin@example.com",
        password="testpass123",
        name="Ada Admin",
    )


def _client_for(user):
    client = APIClient()
    refresh = RefreshToken.for_user(user)
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {refresh.access_token}")
    return client


@pytest.fixture
def api_client():
    return APIClient()


@pytest.fixture
def passenger_client(passenger_user):
    return _client_for(passenger_user)


@pytest.fixture
def rider_client(rider_user):
    return _client_for(rider_user)


@pytest.fixture
def admin_client(admin_user):
    return _client_for(admin_user)
