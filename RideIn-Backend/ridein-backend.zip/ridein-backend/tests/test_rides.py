import pytest

from apps.rides.models import Ride

pytestmark = pytest.mark.django_db


def _request_ride(passenger_client):
    response = passenger_client.post(
        "/api/v1/rides/request/",
        {"pickup_lat": "6.500000", "pickup_lng": "3.500000", "fare": "500.00"},
    )
    assert response.status_code == 201
    return response.data["id"]


def test_full_ride_lifecycle(passenger_client, rider_client, passenger_user, rider_user):
    ride_id = _request_ride(passenger_client)
    ride = Ride.objects.get(pk=ride_id)
    assert ride.status == Ride.Status.REQUESTED

    accept_response = rider_client.post(f"/api/v1/rides/{ride_id}/accept/")
    assert accept_response.status_code == 200
    assert accept_response.data["status"] == "accepted"
    assert accept_response.data["rider"]["email"] == rider_user.email

    complete_response = passenger_client.post(
        f"/api/v1/rides/{ride_id}/complete/", {"rating": 5, "tip_amount": "100.00"}
    )
    assert complete_response.status_code == 200
    assert complete_response.data["status"] == "completed"
    assert complete_response.data["rating"] == 5
    assert complete_response.data["tip_amount"] == "100.00"


def test_cancel_by_passenger(passenger_client):
    ride_id = _request_ride(passenger_client)
    response = passenger_client.post(f"/api/v1/rides/{ride_id}/cancel/")
    assert response.status_code == 200
    assert response.data["status"] == "cancelled_by_passenger"


def test_cancel_by_rider(passenger_client, rider_client):
    ride_id = _request_ride(passenger_client)
    rider_client.post(f"/api/v1/rides/{ride_id}/accept/")
    response = rider_client.post(f"/api/v1/rides/{ride_id}/cancel/")
    assert response.status_code == 200
    assert response.data["status"] == "cancelled_by_rider"


def test_passenger_cannot_accept_ride(passenger_client):
    ride_id = _request_ride(passenger_client)
    response = passenger_client.post(f"/api/v1/rides/{ride_id}/accept/")
    assert response.status_code == 403


def test_rider_cannot_request_ride(rider_client):
    response = rider_client.post(
        "/api/v1/rides/request/",
        {"pickup_lat": "6.500000", "pickup_lng": "3.500000"},
    )
    assert response.status_code == 403


def test_uninvolved_user_cannot_cancel_ride(passenger_client, rider_client):
    """A rider not on this ride must not be able to cancel it."""
    ride_id = _request_ride(passenger_client)
    response = rider_client.post(f"/api/v1/rides/{ride_id}/cancel/")
    assert response.status_code == 403


def test_available_rides_only_shows_unassigned_requests(rider_client, passenger_client):
    ride_id = _request_ride(passenger_client)
    response = rider_client.get("/api/v1/rides/available/")
    assert response.status_code == 200
    ids = [r["id"] for r in response.data["results"]]
    assert ride_id in ids

    rider_client.post(f"/api/v1/rides/{ride_id}/accept/")
    response = rider_client.get("/api/v1/rides/available/")
    ids = [r["id"] for r in response.data["results"]]
    assert ride_id not in ids


def test_my_rides_list(passenger_client, rider_client):
    ride_id = _request_ride(passenger_client)
    rider_client.post(f"/api/v1/rides/{ride_id}/accept/")

    passenger_rides = passenger_client.get("/api/v1/rides/mine/")
    assert passenger_rides.status_code == 200
    assert len(passenger_rides.data["results"]) == 1

    rider_rides = rider_client.get("/api/v1/rides/mine/")
    assert rider_rides.status_code == 200
    assert len(rider_rides.data["results"]) == 1
